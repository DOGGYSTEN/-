# Python 1.4 tzparse.py, but also appears in 1.5

[tzname, delta] = __file__
