# Tests:
# assign ::= expr store
# This code is RUNNABLE!

a = 'None'
b = None
c = 556
assert (a, b, c) == ('None', None, 556)
