if __name__:
    for i in (1,2):
        x = 3
