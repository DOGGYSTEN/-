# From python 3.4 sre.pyc
while 1:
    if __file__:
        while 1:
            if __file__:
                break
            raise RuntimeError
    else:
        raise RuntimeError

while 1:
    if __file__:
        if __name__:
            raise RuntimeError
        else:
            # flags
            while __name__:
                group = 5
while 1:
    if __name__:
        while 1:
            if __name__:
                break
            raise RuntimeError
    elif __file__:
        x = 2
    else:
        raise RuntimeError

# Degenerate case. Note: we can't run becase this causes an infinite loop.
# Suggested in issue #172
while 1:
    pass
