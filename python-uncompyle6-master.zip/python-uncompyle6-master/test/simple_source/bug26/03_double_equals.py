# From Python 2.7 parse_starttag HTMLParser.pyc
attrvalue = [1,2]
while attrvalue:
    if attrvalue[:1] == 5 or \
       attrvalue[:1] == 2 == attrvalue[-1:]:
        attrvalue = 10
