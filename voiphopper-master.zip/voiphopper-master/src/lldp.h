struct lldphost {
        unsigned char systemname[40];
};
