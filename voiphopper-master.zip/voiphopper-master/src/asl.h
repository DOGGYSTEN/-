struct macip {
        unsigned char mac[6];
        unsigned char ip[4];
        int count;
};
